void seed_random(int x);
int next_random();
