extern void open_it();
extern void close_it();
