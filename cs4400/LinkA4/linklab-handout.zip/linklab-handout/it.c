#include "it.h"

/* This file is built to "it.so" and linked with examples to implement
   `open_it` and `close_it` as called in the examples. The functions
   don't actually do anything; they just stand in place of functions
   that would do something more interesting if you put a different
   "it.so" in place. */

void open_it()
{
}

void close_it()
{
}
