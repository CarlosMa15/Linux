Author: Carlos Martinez
Date: Aug 23, 2019
File: DepartmentOverview.html

    The DepartmentOverview.html contains the Department Overview requirements.
The department chair will be able to access the professor view with some miner
change. This will allow the department chair to see what is missing. In the 
DepartmentOverview.html the department chair is shown a progress bar to give
a very fast summary of how much is down.

    The CourseStatusPage.html contains the Course Status Page requirements.
The professor will also have the ability to add and remove Evalution Matrix
and student work. The current files for now only contain a static place holder
html page for Evalution Matrix and student work.

For now there are limited examples of courses in the professor page, but the professor
page will have the other professor courses as well in the future. The add/remove Evalution
Matrix and add/remove student work are just there to give an idea of how the professor
will manage the page, they don't have any functionality.

References:
1: w3schools.com - This is the main page where I got about 95% of all the html and css info
that I used to complete this assignment.

2: TAs - The class TAs also helped in clarify the assignment and on some html components.

3: Teacher - He taught/showed lots of the stuff and charified the assignment.

4: I did talk about the assignment with friends becuse we were confused on what to do.
Chris, Igor, Ismeal, and Wi. No code, just on what you wanted us to do based of our understanding.