#!/bin/sh
python3 id3.py